<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\dorr\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/panel.blade.php ENDPATH**/ ?>